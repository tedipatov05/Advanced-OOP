﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ICollection<IIdenticable> identicables = new List<IIdenticable>();

            string input = Console.ReadLine();

            while(input != "End")
            {
                string[] inpArgs = input.Split();
                if(inpArgs.Length == 3)
                {
                    IIdenticable citizen = new Citizen(inpArgs[0], int.Parse(inpArgs[1]), inpArgs[2]);
                    identicables.Add(citizen);
                }
                else if(inpArgs.Length == 2)
                {
                    IIdenticable robot = new Robot(inpArgs[0], inpArgs[1]);
                    identicables.Add(robot);
                }
                input = Console.ReadLine();
            }

            string detainedDigits = Console.ReadLine();

            string[] detrained = identicables.Where(i => i.Id.EndsWith(detainedDigits))
                .Select(i => i.Id)
                .ToArray();
            foreach(string d in detrained)
            {
                Console.WriteLine(d);
            }
                

            
        }
    }
}
