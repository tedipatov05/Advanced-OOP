﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Formula1.Models.Cars
{
    public class Williams : FormulaOneCar
    {
        public Williams(string model, int horsepower, double enginedisplacement) : base(model, horsepower, enginedisplacement)
        {
        }
    }
}
