﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Formula1.Models.Cars
{
    public class Ferrari : FormulaOneCar
    {
        public Ferrari(string model, int horsepower, double enginedisplacement) : base(model, horsepower, enginedisplacement)
        {
        }
    }
}
