﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string nameOfClass, params string[] namesOfFields)
        {
            Type classType = Type.GetType(nameOfClass);
            FieldInfo[] filedsInfo = classType.GetFields(BindingFlags.Instance |
                BindingFlags.NonPublic |
                BindingFlags.Static
                | BindingFlags.Public);
            StringBuilder sb = new StringBuilder();

            var classInstance = Activator.CreateInstance(classType, new object[] {});
            sb.AppendLine($"Class under investigation: {nameOfClass}");

            foreach(FieldInfo field in filedsInfo)
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }
            return sb.ToString().Trim();
        }
    }
}
