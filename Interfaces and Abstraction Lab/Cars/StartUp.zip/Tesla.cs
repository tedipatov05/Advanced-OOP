﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cars
{
    public class Tesla : ICar, IELectricCar
    {
        public string Model { get; private set; }

        public string Color { get; private set; }
        public int Batery { get; private set; }

        public Tesla(string model, string color, int batery)
        {
            Model = model;
            Color = color;
            Batery = batery;
        }

        public string Start()
        {
            return "Engine start";
        }

        public string Stop()
        {
            return "Breaak!";
        }

        public override string ToString()
        { 
            return $"{Color} Tesla {Model} with {Batery} Batteries";
        }


    }
}
