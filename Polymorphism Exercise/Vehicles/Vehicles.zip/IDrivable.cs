﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    internal interface IDrivable
    {
        public void Drive(double fuel);
    }
}
