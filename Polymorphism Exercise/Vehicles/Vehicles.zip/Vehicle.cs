﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Vehicle : IDrivable, IRefuable
    {
        private double fuelQuantity;
        private double fuelConsumption;

        public Vehicle(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity
        {
            get { return fuelQuantity; }
            protected set
            {
                if(value < 0)
                {
                    throw new ArgumentException("The fuel cannot be less than zero");
                }
                this.fuelQuantity = value;
            }
        }

        public double FuelConsumption
        {
            get { return fuelConsumption; }
            protected set
            {
                if(value < 0)
                {
                    throw new ArgumentException("FuelConsumption cannot be less than zero");
                }
                fuelConsumption = value;
            }
        }

        public void Drive(double distance)
        {
            double fuel = FuelConsumption * distance;
            if(fuel > FuelQuantity)
            {
                throw new ArgumentException($"{GetType().Name} needs refueling");
            }
            FuelQuantity -= fuel;
            Console.WriteLine($"{GetType().Name} travelled {distance} km");
        }

        public virtual void Refuel(double fuel)
        {
            FuelQuantity += fuel;
        }

        public override string ToString()
        {
            return $"{GetType().Name}: {FuelQuantity:f2}";
        }

    }
}
