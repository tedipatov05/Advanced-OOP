﻿using System;

namespace Vehicles
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
            Engine engine = new Engine();
            engine.Run();

        }
    }
}
