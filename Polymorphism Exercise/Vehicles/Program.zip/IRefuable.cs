﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    internal interface IRefuable
    {
        public void Refuel(double fuel);
    }
}
